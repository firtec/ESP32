/*****************************************************************************
*  Descripci�n  : OPT3001 + ESP32 + MQTT
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V5.0
*         www.firtec.com.ar
*****************************************************************************/

    sbit LCD_RS at GPIOE_ODR.B4;
    sbit LCD_EN at GPIOE_ODR.B6;
    sbit LCD_D4 at GPIOC_ODR.B12;
    sbit LCD_D5 at GPIOC_ODR.B13;
    sbit LCD_D6 at GPIOC_ODR.B14;
    sbit LCD_D7 at GPIOC_ODR.B15;

#define SLAVE_ADDRESS 0x44
unsigned char tmp_data[12];
char floatStr[10];
char txt_viejo[10];
unsigned char temp;
float luz_ambiente = 0;

unsigned char datoRX;
unsigned char kbhit = 0;
char Str[4];

/******************************************************************************
*     Funci�n para el env�o de cadenas por el puerto UART.
******************************************************************************/
void Enviar_String(const char *s)
{
  while(*s)
  {
    UART2_Write(*s++);
  }
}
/*****************************************************
*        Esta funci�n configura el sensor OPT3001
******************************************************/
void Config_Sensor(){
        tmp_data[0] = 0x01;    // Registro de configuraci�n
        tmp_data[1] = 0xC6;    // Configura el conversor A/D
        tmp_data[2] = 0x10;    // Modo de conversi�n continua
        I2C1_Start();
        I2C1_Write(SLAVE_ADDRESS,tmp_data,3,END_MODE_STOP);
}
/*****************************************************
*        Esta funci�n lee la cantidad de luz ambiente
******************************************************/
float Leer_Sensor() {
  unsigned int DataSum;
  float Ambient_Data;
  tmp_data[0] = 0x00;
  I2C1_Start();
  I2C1_Write(SLAVE_ADDRESS,tmp_data,1,END_MODE_RESTART);
  I2C1_Read(SLAVE_ADDRESS,tmp_data,2,END_MODE_STOP);
  DataSum = ((tmp_data[0] << 8) | tmp_data[1]);
  tmp_data[0] = tmp_data[0] >> 4;
  DataSum = DataSum << 4;
  DataSum = DataSum >> 4;
  Ambient_Data = 0.01 * (2 << tmp_data[0]) * DataSum;

  if (Ambient_Data >= 1000.0)
     Ambient_data = 1000.0;
     Ambient_Data  /= 10;
  return Ambient_Data;
}

void main(){
  Lcd_Init();
  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);
  I2C1_Init_Advanced(100000, &_GPIO_MODULE_I2C1_PB87);
  UART2_Init_Advanced(9600, _UART_8_BIT_DATA, _UART_NOPARITY,
                            _UART_ONE_STOPBIT, &_GPIO_MODULE_USART2_PA23);
  EnableInterrupts();
  UE_USART2_CR1_bit = 1;
  RE_USART2_CR1_bit = 1;
  RXNEIE_USART2_CR1_bit = 0; 
  TXEIE_USART2_CR1_bit = 0;
  //NVIC_IntEnable(IVT_INT_USART2);

  Delay_ms(200);
  Config_Sensor();
  Lcd_Out(1,2,"STM32+OPT3001+MQTT");      
  Lcd_Out(4,2,"Luz Visible:");
  Lcd_Out(2,1,"IP:[192.168.1.12]");
  Lcd_Out(3,1,"Topic:/firtec/S1/LUZ");

  while(1) {                         // Bucle infinito
        luz_ambiente = Leer_Sensor();
    sprintf(floatStr, "%3.1f%%  ", luz_ambiente);
    temp = strcmp(floatStr,txt_viejo);  // Compara las cadenas
         if(temp != 0){
                  Lcd_Out(4,15,floatStr);
                  UART2_Write(luz_ambiente);
                  strcpy(txt_viejo,floatStr);  // Actualiza nuevo valor
         }
   Delay_ms(1000);
   }
  }
//******************* Fin de archivo - FIRTEC ARGENTINA ***********************