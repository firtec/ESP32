/* 
 * File:   main.c
 * Author: www.firtec.com.ar
 *
 */

#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
#include <plib/usart.h>


#pragma config OSC=HS,PWRT=ON,MCLRE=ON,LVP=OFF,WDT=OFF

#include "C:\ELECTR�NICA\Programas PIC\2018\LCD\lcd_xc8.c"
#include "C:\ELECTR�NICA\Programas PIC\2018\LCD\lcd_xc8.h"

#include "1wire.h"

 void xputsUSART (char *data);
 void xputrsUSART (const char *data);

#define _XTAL_FREQ 10000000

volatile unsigned char DatoRX;


void delay(unsigned int t){ 
while(t--)
    __delay_ms(1);
}

//****************** Se discrimina el origen de la interrupci�n*************

void interrupt high_isr (void)
{
if (PIR1bits.RCIF==1){ // Discrimina la inte del receptor
DatoRX = getcUSART(); // Se lee dato recibido
if(DatoRX == '1'){
	PORTCbits.RC2 = 1; 
}
if(DatoRX == '2'){
	PORTCbits.RC2 = 0;
}
PIR1bits.RCIF=0; // Borra bandera de interrupci�n
 }
}

//**************************************************************************/
void main(void){
float Grados=0; 	// Variable para contener el dato temperatura
char TempStr[5];	// String para convertir el dato en caracteres
TRISCbits.TRISC2=0;
PORTCbits.RC2 = 0;
OpenUSART (USART_TX_INT_OFF & 	// TX sin interrupci�n
           USART_RX_INT_ON &	// RX con interrupci�nes
           USART_ASYNCH_MODE &	// Modo asincr�nico
           USART_EIGHT_BIT &	// Modo alta velocidad
           USART_CONT_RX &  	// Recepci�n continua
           USART_BRGH_HIGH,32); // 19200 baudios a 10Mhz
RCONbits.IPEN = 0; // Deshabilitamos prioridades
INTCONbits.PEIE=1; // Habilitamos la interrupcion de perifericos
INTCONbits.GIE=1; //Habilita interrupci�n global
lcd_init();	 //Inicializa el LCD

delay(2000);  // Espera 2 segundos para empezar a medir la temperatura.
lcd_gotoxy(2,1);
lcd_putrs("PIC18 con MQTT"); 
lcd_gotoxy(1,2);
lcd_putrs("Temperatura:    ");

while(1){
  Convert_Temperature();	
  Grados = Read_Temperature_DS18B20();
   sprintf(TempStr,"%2.1f", Grados);
    lcd_gotoxy(13,2);     
      lcd_puts(TempStr);
      xputsUSART(TempStr);
    delay(1000);

 }
}

