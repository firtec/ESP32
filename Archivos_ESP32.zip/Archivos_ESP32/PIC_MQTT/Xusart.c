/*
 * File:   XUSART.c
 *    www.firtec.com.ar
 *
 * Created on 25 de abril de 2014, 11:24
 */

#include <xc.h>
#include <plib/usart.h>

/**********************************************************************
*   Esta funci�n transmite un string de caracteres almacenados en     *
*   memoria de programa.                                              *
**********************************************************************/
void xputrsUSART(const char *data)
{
  while(*data != '\0')
  {  
    while(BusyUSART());
    putcUSART(*data);
	*data++;
  }
}
/**********************************************************************
*  Esta funci�n transmite un String de caracteres almacenados en      *
*  memoria RAM.                                                       *
**********************************************************************/
void xputsUSART(char *data)
{
  while(*data != '\0')
  {  
    while(BusyUSART());
    putcUSART(*data);
	*data++;
  }
}
